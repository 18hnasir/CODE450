To run the program, do the following: 

	1. Open the cmd or terminal

	2. Go to the directory that contains the python file "my-dns-client.py"

	3. In the cmd/terminal, type the command "python my-dns-client.py (hostname)" 
	   (hostname) being "www.cnn.com" or "www.gmu.edu"

	4. Observe the output and run the command above again for different hostnames